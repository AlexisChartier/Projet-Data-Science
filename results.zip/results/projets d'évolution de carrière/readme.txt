Ce répertoire contient le résultat pour l'analyse sur la colonne : 'Quels sont vos projets d'évolution de carrière ?' via une analyse de thèmes via spacy
Le script python associé est projetsEvolution.py sur le github dans le repertoire scripts.
Les résultats comprennent : 1 nuage de mots global à toutes les filières et 1 nuage de mots spécifiques à chaque filière