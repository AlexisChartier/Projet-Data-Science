Ce répertoire contient le résultat pour l'analyse sur la colonne : 'Quelle(s) difficulté(s) rencontrez-vous dans votre recherche d\'emploi?' 
en utilisant le modele bertopic pour une analyse de topics.
Le script python associé est difficultésEmploi.py sur le github dans le repertoire scripts.
Les résultats comprennent : 1 visualisation des topics sous la forme d'un graphe 2D et 1 visualisation des termes les plus fréquents par topic sous la forme d'un barchart