Ce répertoire contient le résultat pour l'analyse sur la colonne : 'Pour quelle raison avez-vous principalement choisi de poursuivre des études ?' 
en utilisant le modele bertopic pour une analyse de topics.
Le script python associé est motivPoursuiteEtude.py sur le github dans le repertoire scripts.
Les résultats comprennent : 1 visualisation des topics sous la forme d'un graphe 2D et 1 visualisation des termes les plus fréquents par topic sous la forme d'un barchart