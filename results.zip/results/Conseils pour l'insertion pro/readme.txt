Ce répertoire contient le résultat pour l'analyse sur la colonne : 'Quels conseils pourriez-vous donner aux étudiants actuellement en formation pour bien choisir leur stage de fin d\'étude ? réussir leur insertion professionnelle ?' 
en utilisant le modele bertopic pour une analyse thématique avec nmf et tf idf
Le script python associé est conseilsInsertion.py sur le github dans le repertoire scripts.
Les résultats comprennent : 1 nuages de mots par filiere