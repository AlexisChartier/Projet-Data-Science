Ce répertoire contient le résultat pour l'analyse sur les colonne : 'Quels enseignements vous semblent les plus utiles pour l\'exercice de votre métier et votre insertion professionnelle ?' 
Parmi les enseignements fournis par l\'école, quels sont ceux qui mériteraient d\'être approfondis ou renforcés ?
 ...
 ...
en utilisant une analyse de frequence de mots
Le script python associé est avisUE.py sur le github dans le repertoire scripts.
Les résultats comprennent : 1 barchart des 3 UE les plus reccurrentes pour chaque filiere et pour chaque categorie : 
UE utile a l'insertion
UE aurait merite d'etre approfondis
UE absente qui aurait été utile
UE inutile